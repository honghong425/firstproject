package com.fashionNav.controller;

import com.fashionNav.model.entity.News;
import com.fashionNav.service.NewsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/news")
public class NewsController {

    @Autowired
    private NewsService newsService;

    @PostMapping
    public ResponseEntity<Void> insertNews(@RequestBody News news) {
        newsService.insertNews(news);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/{id}")
    public ResponseEntity<News> getNews(@PathVariable("id") int newsId) {
        News news = newsService.getNews(newsId);
        return news != null ? ResponseEntity.ok(news) : ResponseEntity.notFound().build();
    }

    @GetMapping
    public ResponseEntity<List<News>> getAllNews() {
        return ResponseEntity.ok(newsService.getAllNews());
    }

    @PutMapping("/{id}")
    public ResponseEntity<Void> updateNews(@PathVariable("id") int newsId, @RequestBody News news) {
        news.setNewsId(newsId);
        try {
            newsService.updateNews(news);
            return ResponseEntity.ok().build();
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteNews(@PathVariable("id") int newsId) {
        try {
            newsService.deleteNews(newsId);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/{id}/like")
    public ResponseEntity<Void> likeNews(@PathVariable("id") int newsId) {
        try {
            newsService.addLikeCount(newsId);
            return new ResponseEntity<>(HttpStatus.OK);
        } catch (RuntimeException e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
