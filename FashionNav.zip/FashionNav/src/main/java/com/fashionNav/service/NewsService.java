package com.fashionNav.service;

import com.fashionNav.model.entity.News;
import com.fashionNav.repository.NewsMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class NewsService {

    private final NewsMapper newsMapper;

    public void insertNews(News news) {
        news.setCreatedAt(LocalDateTime.now());
        news.setUpdatedAt(LocalDateTime.now());
        newsMapper.insertNews(news);
    }

    public News getNews(int newsId) {
        newsMapper.addVisitCount(newsId);
        return newsMapper.getNewsById(newsId);
    }

    public List<News> getAllNews() {
        return newsMapper.getAllNews();
    }

    public void updateNews(News news) {
        newsMapper.updateNews(news);
    }

    public void deleteNews(int newsId) {
        newsMapper.deleteNews(newsId);
    }

    public void addLikeCount(int newsId) {
        newsMapper.addLikeCount(newsId);
    }
}
