package com.fashionNav;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FashionNavApplicationTests {

	@Test
	void contextLoads() {
	}

}
